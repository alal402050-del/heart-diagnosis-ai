
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
import numpy as np
import joblib
import os

app = FastAPI()

model_path = os.path.join("model", "heart_model.pkl")
model = joblib.load(model_path)

templates = Jinja2Templates(directory="app/templates")

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse("index.html", {"request": request})

@app.post("/predict")
async def predict(data: dict):
    try:
        age = data["Age"]
        sex = 1 if data["Sex"] == "M" else 0
        cp_map = {"ATA": 0, "NAP": 1, "ASY": 2, "TA": 3}
        cp = cp_map[data["ChestPainType"]]
        bp = data["RestingBP"]
        chol = data["Cholesterol"]
        maxhr = data["MaxHR"]
        exang = 1 if data["ExerciseAngina"] == "Y" else 0
        oldpeak = data["Oldpeak"]
        slope_map = {"Up": 0, "Flat": 1, "Down": 2}
        slope = slope_map[data["ST_Slope"]]

        features = np.array([[age, sex, cp, bp, chol, maxhr, exang, oldpeak, slope]])
        probability = float(model.predict_proba(features)[0][1])
        label = int(probability > 0.5)
        return JSONResponse({"label": label, "probability": probability})
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)
