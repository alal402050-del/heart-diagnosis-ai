# Heart Diagnosis AI
A FastAPI ML app.